# SQL Field List Formatter v4

A Visual Studio Code extension that formats selected SQL field lists into aligned columns with smarter alias handling.

## New in v4

- Smarter handling of explicit aliases such as `AS [Alias Name]`
- Configurable alias formatting modes:
  - `preserve`
  - `normalize`
  - `align`
- Configurable spacing before and after `AS`
- Keeps the existing v3 improvements for:
  - SQL comment awareness
  - leading-comma first-row alignment
  - trailing-comma alignment
  - context menu and keyboard shortcuts
  - prebuilt `.vsix`

## Alias settings

```json
{
  "fieldListFormatter.aliasFormat": "normalize",
  "fieldListFormatter.aliasSpacingBeforeAs": 1,
  "fieldListFormatter.aliasSpacingAfterAs": 1
}
```

### `fieldListFormatter.aliasFormat`

- `preserve`
  - Leave alias spacing exactly as it appears in the selected text.
- `normalize`
  - Rewrite aliases using the configured `aliasSpacingBeforeAs` and `aliasSpacingAfterAs` values.
- `align`
  - Within each output column, vertically align the `AS` keyword based on the longest expression in that column, then apply the configured spacing values.

## Example input

```sql
    mn.Employee_ID AS [Employee ID]
  , mn.Employee_Name    AS    [Employee Name]
  , COALESCE(mn.Display_Name, mn.Employee_Name) AS [Display Name]
  , mn.Manager_ID AS [Manager ID]
  , mn.Product_Name AS [Product Name]
  , mn.Location_Name    AS[Location Name]
```

## Example output (`aliasFormat = normalize`)

```sql
  mn.Employee_ID AS [Employee ID]                               , mn.Employee_Name AS [Employee Name], COALESCE(mn.Display_Name, mn.Employee_Name) AS [Display Name]
, mn.Manager_ID  AS [Manager ID]                               , mn.Product_Name AS [Product Name]  , mn.Location_Name AS [Location Name]
```

## Example output (`aliasFormat = align`)

```sql
  mn.Employee_ID                                      AS [Employee ID] , mn.Employee_Name AS [Employee Name], COALESCE(mn.Display_Name, mn.Employee_Name) AS [Display Name]
, mn.Manager_ID                                       AS [Manager ID]  , mn.Product_Name AS [Product Name]  , mn.Location_Name  AS [Location Name]
```

## Install the prebuilt `.vsix`

1. Open VS Code.
2. Run **Extensions: Install from VSIX...**
3. Pick the included `.vsix` file.

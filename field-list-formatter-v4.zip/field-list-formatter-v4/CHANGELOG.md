# Change Log

## 0.4.0

- Added smarter parsing of explicit `AS` aliases.
- Added configurable alias formatting modes: `preserve`, `normalize`, and `align`.
- Added configurable spacing before and after `AS`.
- Preserved v3 SQL comment handling and comma alignment behavior.

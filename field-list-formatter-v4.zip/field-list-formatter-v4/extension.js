const vscode = require('vscode');

function activate(context) {
    const subscriptions = [];

    subscriptions.push(vscode.commands.registerCommand(
        'fieldListFormatter.formatIntoFiveColumns',
        async () => formatSelection(5)
    ));

    subscriptions.push(vscode.commands.registerCommand(
        'fieldListFormatter.formatIntoConfiguredColumns',
        async () => {
            const config = getConfig();
            await formatSelection(config.columns);
        }
    ));

    subscriptions.push(vscode.commands.registerCommand(
        'fieldListFormatter.promptForColumns',
        async () => {
            const config = getConfig();
            const answer = await vscode.window.showInputBox({
                prompt: 'Enter the number of columns to format into',
                value: String(config.columns),
                validateInput: value => {
                    const parsed = Number(value);
                    if (!Number.isInteger(parsed) || parsed < 1) {
                        return 'Enter a whole number greater than or equal to 1.';
                    }
                    return null;
                }
            });

            if (!answer) {
                return;
            }

            await formatSelection(Number(answer));
        }
    ));

    for (let columns = 2; columns <= 9; columns++) {
        subscriptions.push(vscode.commands.registerCommand(
            `fieldListFormatter.formatInto${columns}Columns`,
            async () => formatSelection(columns)
        ));
    }

    context.subscriptions.push(...subscriptions);
}

function getConfig() {
    const config = vscode.workspace.getConfiguration('fieldListFormatter');
    return {
        columns: Math.max(1, Number(config.get('columns', 5)) || 5),
        commaStyle: normalizeCommaStyle(config.get('commaStyle', 'leading')),
        firstLinePrefixMode: normalizeFirstLinePrefixMode(config.get('firstLinePrefixMode', 'pad')),
        preserveIndentation: Boolean(config.get('preserveIndentation', false)),
        preserveBlankLines: Boolean(config.get('preserveBlankLines', false)),
        aliasFormat: normalizeAliasFormat(config.get('aliasFormat', 'normalize')),
        aliasSpacingBeforeAs: Math.max(0, Number(config.get('aliasSpacingBeforeAs', 1)) || 0),
        aliasSpacingAfterAs: Math.max(1, Number(config.get('aliasSpacingAfterAs', 1)) || 1)
    };
}

function normalizeCommaStyle(value) {
    return value === 'trailing' ? 'trailing' : 'leading';
}

function normalizeFirstLinePrefixMode(value) {
    switch (value) {
        case 'none':
        case 'commaSpace':
        case 'pad':
            return value;
        default:
            return 'pad';
    }
}

function normalizeAliasFormat(value) {
    switch (value) {
        case 'preserve':
        case 'normalize':
        case 'align':
            return value;
        default:
            return 'normalize';
    }
}

async function formatSelection(columns) {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
        vscode.window.showInformationMessage('Field List Formatter: No active editor found.');
        return;
    }

    const document = editor.document;
    const config = getConfig();
    const normalizedColumns = Math.max(1, Number(columns) || config.columns || 5);

    await editor.edit(editBuilder => {
        for (const selection of editor.selections) {
            const range = selection.isEmpty
                ? new vscode.Range(selection.start.line, 0, selection.end.line, document.lineAt(selection.end.line).text.length)
                : selection;

            const originalText = document.getText(range);
            const formattedText = formatFieldList(originalText, {
                columns: normalizedColumns,
                commaStyle: config.commaStyle,
                firstLinePrefixMode: config.firstLinePrefixMode,
                preserveIndentation: config.preserveIndentation,
                preserveBlankLines: config.preserveBlankLines,
                aliasFormat: config.aliasFormat,
                aliasSpacingBeforeAs: config.aliasSpacingBeforeAs,
                aliasSpacingAfterAs: config.aliasSpacingAfterAs
            });

            editBuilder.replace(range, formattedText);
        }
    });
}

function formatFieldList(text, options) {
    const newline = text.includes('\r\n') ? '\r\n' : '\n';
    const rawLines = text.replace(/\r\n/g, '\n').split('\n');
    const parsed = parseSqlSelection(rawLines, options);

    if (parsed.items.length === 0) {
        return text;
    }

    const rows = [];
    for (let i = 0; i < parsed.items.length; i += options.columns) {
        rows.push(parsed.items.slice(i, i + options.columns));
    }

    const aliasExpressionWidths = calculateAliasExpressionWidths(rows, options.columns, options.aliasFormat);
    const renderedGrid = rows.map(row => row.map((item, colIndex) => renderItem(item, colIndex, aliasExpressionWidths, options)));

    const widths = Array.from({ length: options.columns }, (_, colIndex) => {
        let maxLength = 0;
        for (const row of renderedGrid) {
            if (row[colIndex]) {
                maxLength = Math.max(maxLength, row[colIndex].length);
            }
        }
        return maxLength;
    });

    const formattedRows = renderedGrid.map((row, rowIndex) => renderRowFromGrid(row, rowIndex, renderedGrid.length, widths, parsed.baseIndent, options));

    if (!options.preserveBlankLines || parsed.blankLineIndexes.size === 0) {
        return formattedRows.join(newline);
    }

    const output = [];
    let nextRow = 0;
    for (let sourceIndex = 0; sourceIndex < rawLines.length; sourceIndex++) {
        if (parsed.blankLineIndexes.has(sourceIndex)) {
            output.push('');
        } else if (nextRow < formattedRows.length) {
            output.push(formattedRows[nextRow++]);
        }
    }

    while (nextRow < formattedRows.length) {
        output.push(formattedRows[nextRow++]);
    }

    return output.join(newline);
}

function renderRowFromGrid(row, rowIndex, rowCount, widths, baseIndent, options) {
    const pieces = [];

    for (let colIndex = 0; colIndex < row.length; colIndex++) {
        const itemText = row[colIndex];
        const isLastInRow = colIndex === row.length - 1;
        const isLastOverall = rowIndex === rowCount - 1 && isLastInRow;

        if (options.commaStyle === 'leading') {
            const prefix = getLeadingPrefix(rowIndex, colIndex, options.firstLinePrefixMode);
            let cell = prefix + itemText;
            if (!isLastInRow) {
                cell += ' '.repeat(Math.max(0, widths[colIndex] - itemText.length));
            }
            pieces.push(cell);
        } else {
            let cell = itemText;
            if (!isLastOverall) {
                cell += ' '.repeat(Math.max(0, widths[colIndex] - itemText.length));
                cell += ',';
                if (!isLastInRow) {
                    cell += ' ';
                }
            }
            pieces.push(cell);
        }
    }

    return baseIndent + pieces.join('');
}

function getLeadingPrefix(rowIndex, colIndex, firstLinePrefixMode) {
    const isFirstCell = rowIndex === 0 && colIndex === 0;
    if (!isFirstCell) {
        return ', ';
    }

    switch (firstLinePrefixMode) {
        case 'commaSpace':
            return ', ';
        case 'pad':
            return '  ';
        case 'none':
        default:
            return '';
    }
}

function parseSqlSelection(rawLines, options) {
    const blankLineIndexes = new Set();
    const items = [];
    const normalizedForIndent = [];
    let inBlockComment = false;

    rawLines.forEach((rawLine, index) => {
        const commentStripped = removeSqlComments(rawLine, () => inBlockComment, value => {
            inBlockComment = value;
        });

        if (commentStripped.trim().length === 0) {
            if (options.preserveBlankLines && rawLine.trim().length === 0) {
                blankLineIndexes.add(index);
            }
            return;
        }

        const normalized = normalizeFieldExpression(commentStripped);
        if (!normalized) {
            return;
        }

        items.push(splitAliasParts(normalized));
        normalizedForIndent.push(commentStripped);
    });

    const baseIndent = options.preserveIndentation
        ? calculateBaseIndent(normalizedForIndent)
        : '';

    return {
        items,
        blankLineIndexes,
        baseIndent
    };
}

function calculateBaseIndent(lines) {
    let smallest = null;
    for (const line of lines) {
        const indent = getVisualIndentBeforeField(line);
        if (smallest === null || indent.length < smallest.length) {
            smallest = indent;
        }
    }
    return smallest || '';
}

function getVisualIndentBeforeField(line) {
    const leadingWhitespace = (line.match(/^\s*/) || [''])[0];
    const afterWhitespace = line.slice(leadingWhitespace.length);
    if (afterWhitespace.startsWith(',')) {
        const remainder = afterWhitespace.slice(1);
        const spaceMatch = remainder.match(/^\s*/);
        const commaPadding = 1 + (spaceMatch ? spaceMatch[0].length : 0);
        return leadingWhitespace + ' '.repeat(commaPadding);
    }
    return leadingWhitespace;
}

function normalizeFieldExpression(line) {
    const trimmed = line.trim();
    if (!trimmed) {
        return '';
    }

    let start = 0;
    while (start < trimmed.length && /\s/.test(trimmed[start])) {
        start++;
    }
    if (trimmed[start] === ',') {
        start++;
        while (start < trimmed.length && /\s/.test(trimmed[start])) {
            start++;
        }
    }

    let value = trimmed.slice(start);
    const end = findTrailingCommaIndex(value);
    if (end >= 0) {
        value = value.slice(0, end) + value.slice(end + 1);
    }

    return value.trim();
}

function splitAliasParts(value) {
    let inSingleQuote = false;
    let inDoubleQuote = false;
    let inBracket = false;
    let parenDepth = 0;
    let candidate = -1;

    for (let i = 0; i < value.length - 1; i++) {
        const ch = value[i];
        const next = value[i + 1];
        const prev = i > 0 ? value[i - 1] : '';

        if (inSingleQuote) {
            if (ch === '\'' && next === '\'') {
                i++;
                continue;
            }
            if (ch === '\'') {
                inSingleQuote = false;
            }
            continue;
        }

        if (inDoubleQuote) {
            if (ch === '"' && next === '"') {
                i++;
                continue;
            }
            if (ch === '"') {
                inDoubleQuote = false;
            }
            continue;
        }

        if (inBracket) {
            if (ch === ']') {
                inBracket = false;
            }
            continue;
        }

        if (ch === '\'') {
            inSingleQuote = true;
            continue;
        }
        if (ch === '"') {
            inDoubleQuote = true;
            continue;
        }
        if (ch === '[') {
            inBracket = true;
            continue;
        }
        if (ch === '(') {
            parenDepth++;
            continue;
        }
        if (ch === ')' && parenDepth > 0) {
            parenDepth--;
            continue;
        }

        if (parenDepth === 0 && (ch === 'A' || ch === 'a') && (next === 'S' || next === 's')) {
            const beforeOk = i === 0 || /\s/.test(prev);
            const afterChar = i + 2 < value.length ? value[i + 2] : '';
            const afterOk = afterChar && /\s/.test(afterChar);
            if (beforeOk && afterOk) {
                candidate = i;
            }
        }
    }

    if (candidate < 0) {
        return {
            hasAlias: false,
            raw: value,
            expression: value,
            alias: '',
            expressionOriginal: value,
            aliasOriginal: ''
        };
    }

    const before = value.slice(0, candidate).replace(/\s+$/, '');
    const after = value.slice(candidate + 2).replace(/^\s+/, '');
    if (!before || !after) {
        return {
            hasAlias: false,
            raw: value,
            expression: value,
            alias: '',
            expressionOriginal: value,
            aliasOriginal: ''
        };
    }

    return {
        hasAlias: true,
        raw: value,
        expression: before,
        alias: after,
        expressionOriginal: before,
        aliasOriginal: after
    };
}

function calculateAliasExpressionWidths(rows, columnCount, aliasFormat) {
    const widths = Array.from({ length: columnCount }, () => 0);
    if (aliasFormat !== 'align') {
        return widths;
    }

    rows.forEach(row => {
        row.forEach((item, colIndex) => {
            if (item && item.hasAlias) {
                widths[colIndex] = Math.max(widths[colIndex], item.expression.length);
            }
        });
    });

    return widths;
}

function renderItem(item, colIndex, aliasExpressionWidths, options) {
    if (!item.hasAlias || options.aliasFormat === 'preserve') {
        return item.raw;
    }

    const beforeAsSpaces = ' '.repeat(options.aliasSpacingBeforeAs);
    const afterAsSpaces = ' '.repeat(options.aliasSpacingAfterAs);
    let expression = item.expression;

    if (options.aliasFormat === 'align') {
        const targetWidth = aliasExpressionWidths[colIndex] || item.expression.length;
        expression = expression.padEnd(targetWidth, ' ');
    }

    return `${expression}${beforeAsSpaces}AS${afterAsSpaces}${item.alias}`;
}

function findTrailingCommaIndex(value) {
    let inSingleQuote = false;
    let inDoubleQuote = false;
    let inBracket = false;
    let parenDepth = 0;
    let lastSignificantIndex = -1;

    for (let i = 0; i < value.length; i++) {
        const ch = value[i];
        const next = i + 1 < value.length ? value[i + 1] : '';

        if (inSingleQuote) {
            if (ch === '\'' && next === '\'') {
                i++;
                continue;
            }
            if (ch === '\'') {
                inSingleQuote = false;
            }
            continue;
        }

        if (inDoubleQuote) {
            if (ch === '"' && next === '"') {
                i++;
                continue;
            }
            if (ch === '"') {
                inDoubleQuote = false;
            }
            continue;
        }

        if (inBracket) {
            if (ch === ']') {
                inBracket = false;
            }
            continue;
        }

        if (ch === '\'') {
            inSingleQuote = true;
            continue;
        }
        if (ch === '"') {
            inDoubleQuote = true;
            continue;
        }
        if (ch === '[') {
            inBracket = true;
            continue;
        }
        if (ch === '(') {
            parenDepth++;
            continue;
        }
        if (ch === ')' && parenDepth > 0) {
            parenDepth--;
            continue;
        }
        if (!/\s/.test(ch)) {
            lastSignificantIndex = i;
        }
    }

    return lastSignificantIndex >= 0 && value[lastSignificantIndex] === ',' ? lastSignificantIndex : -1;
}

function removeSqlComments(line, getBlockCommentState, setBlockCommentState) {
    let inBlockComment = getBlockCommentState();
    let inSingleQuote = false;
    let inDoubleQuote = false;
    let inBracket = false;
    let result = '';

    for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        const next = i + 1 < line.length ? line[i + 1] : '';

        if (inBlockComment) {
            if (ch === '*' && next === '/') {
                inBlockComment = false;
                setBlockCommentState(false);
                i++;
            }
            continue;
        }

        if (inSingleQuote) {
            result += ch;
            if (ch === '\'' && next === '\'') {
                result += next;
                i++;
                continue;
            }
            if (ch === '\'') {
                inSingleQuote = false;
            }
            continue;
        }

        if (inDoubleQuote) {
            result += ch;
            if (ch === '"' && next === '"') {
                result += next;
                i++;
                continue;
            }
            if (ch === '"') {
                inDoubleQuote = false;
            }
            continue;
        }

        if (inBracket) {
            result += ch;
            if (ch === ']') {
                inBracket = false;
            }
            continue;
        }

        if (ch === '-' && next === '-') {
            break;
        }
        if (ch === '/' && next === '*') {
            inBlockComment = true;
            setBlockCommentState(true);
            i++;
            continue;
        }
        if (ch === '\'') {
            inSingleQuote = true;
            result += ch;
            continue;
        }
        if (ch === '"') {
            inDoubleQuote = true;
            result += ch;
            continue;
        }
        if (ch === '[') {
            inBracket = true;
            result += ch;
            continue;
        }

        result += ch;
    }

    return result;
}

function deactivate() {}

module.exports = {
    activate,
    deactivate,
    formatFieldList,
    parseSqlSelection,
    removeSqlComments,
    normalizeFieldExpression,
    splitAliasParts,
    renderItem,
    calculateAliasExpressionWidths,
    getVisualIndentBeforeField,
    findTrailingCommaIndex
};

# Change Log

## 0.5.0

- Added implicit alias detection for patterns like `Column AliasName`.
- Added automatic insertion of `AS` for implicit aliases in `normalize` and `align` modes.
- Added column-aware alias alignment that only aligns when a column contains multiple aliased items.
- Added `list` layout mode and a new `Format As List` command.

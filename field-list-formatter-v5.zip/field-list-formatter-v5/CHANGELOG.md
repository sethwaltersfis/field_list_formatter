# Change Log

## 0.5.0

- Added implicit alias detection for patterns like `Column AliasName`.
- Added automatic insertion of `AS` for implicit aliases in `normalize` and `align` modes.
- Added column-aware alias alignment that only aligns when a column contains multiple aliased items.
- Added `list` layout mode and a new `Format As List` command.

## 0.4.0

- Added smarter parsing of explicit `AS` aliases.
- Added configurable alias formatting modes: `preserve`, `normalize`, and `align`.
- Added configurable spacing before and after `AS`.
- Preserved v3 SQL comment handling and comma alignment behavior.

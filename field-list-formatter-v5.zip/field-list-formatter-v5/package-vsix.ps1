param(
    [switch]$InstallDependencies
)

if ($InstallDependencies) {
    npm install
}

npx @vscode/vsce package

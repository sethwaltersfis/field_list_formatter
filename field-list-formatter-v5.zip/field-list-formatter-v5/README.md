# SQL Field List Formatter v5

A Visual Studio Code extension that formats selected SQL field lists into aligned columns **or** a single-column list, with smarter alias handling.

## New in v5

- Detects aliases **without** `AS` and upgrades them to use `AS` automatically when alias formatting is `normalize` or `align`
- Vertically aligns `AS` within a column **only when two or more items in that column are aliased**
- Adds a **list** layout mode that converts a multi-column field list into one field per line
- List mode also aligns aliased items vertically because the entire output becomes a single column

## New settings

```json
{
  "fieldListFormatter.layoutMode": "grid",
  "fieldListFormatter.aliasFormat": "align",
  "fieldListFormatter.aliasSpacingBeforeAs": 1,
  "fieldListFormatter.aliasSpacingAfterAs": 1
}
```

### `fieldListFormatter.layoutMode`

- `grid` → format into columns
- `list` → format one item per line

### `fieldListFormatter.aliasFormat`

- `preserve` → keep original alias wording and spacing exactly as selected
- `normalize` → if an alias is present, always emit `AS` with configured spacing
- `align` → same as normalize, but vertically align `AS` when a column has at least two aliased items

## New command

- **Field List Formatter: Format As List**

## Example: aliases without AS in grid mode

Input:

```sql
opp.PO_PRIMARY_SALES_REP_ID
opp.PO_SECONDARY_SALES_REP AS Sec_Sales_Rep
opp.PO_CORE_PSC_SALES_REP
opp.FIS_OVERLAY_REP
opp.FIS_SOLUTION_ARCHITECT_REP
opp.FIS_BUSINESS_DEVELOPMENT_REP
opp.FIS_CM_ACCT_MGR AS Fis_CMA_Mgr
opp.FIS_SPECIALIST_1
opp.FIS_SPECIALIST_2
opp.OWNER_ID AS Own_ID
opp.PO_LAST_OWNER_ID
opp.CREATED_BY Created_By_Name
opp.FIS_CVT_FINAL_CHECK_BY
opp.PO_LAST_HUMAN_MODIFIED_ID
opp.FIS_IFS_BDM
opp.FIS_FIS_EXECUTIVE_SPONSOR
opp.ORIGINATING_LEAD_ID
opp.PO_RELATED_CONTACT_ID
opp.PO_CONSULTANT_ID
```

Example output:

```sql
  opp.PO_PRIMARY_SALES_REP_ID     , opp.PO_SECONDARY_SALES_REP AS Sec_Sales_Rep  , opp.PO_CORE_PSC_SALES_REP , opp.FIS_OVERLAY_REP          , opp.FIS_SOLUTION_ARCHITECT_REP
, opp.FIS_BUSINESS_DEVELOPMENT_REP, opp.FIS_CM_ACCT_MGR        AS Fis_CMA_Mgr    , opp.FIS_SPECIALIST_1      , opp.FIS_SPECIALIST_2         , opp.OWNER_ID AS Own_ID
, opp.PO_LAST_OWNER_ID            , opp.CREATED_BY             AS Created_By_Name, opp.FIS_CVT_FINAL_CHECK_BY, opp.PO_LAST_HUMAN_MODIFIED_ID, opp.FIS_IFS_BDM
, opp.FIS_FIS_EXECUTIVE_SPONSOR   , opp.ORIGINATING_LEAD_ID                      , opp.PO_RELATED_CONTACT_ID , opp.PO_CONSULTANT_ID
```

## Example: list mode

Input:

```sql
  opp.PO_PRIMARY_SALES_REP_ID     , opp.PO_SECONDARY_SALES_REP AS Sec_Sales_Rep, opp.PO_CORE_PSC_SALES_REP , opp.FIS_OVERLAY_REP          , opp.FIS_SOLUTION_ARCHITECT_REP
, opp.FIS_BUSINESS_DEVELOPMENT_REP, opp.FIS_CM_ACCT_MGR AS Fis_CMA_Mgr         , opp.FIS_SPECIALIST_1
```

Output:

```sql
  opp.PO_PRIMARY_SALES_REP_ID
, opp.PO_SECONDARY_SALES_REP        AS Sec_Sales_Rep
, opp.PO_CORE_PSC_SALES_REP
, opp.FIS_OVERLAY_REP
, opp.FIS_SOLUTION_ARCHITECT_REP
, opp.FIS_BUSINESS_DEVELOPMENT_REP
, opp.FIS_CM_ACCT_MGR               AS Fis_CMA_Mgr
, opp.FIS_SPECIALIST_1
```

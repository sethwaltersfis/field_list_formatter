# SQL Field List Formatter v5

A Visual Studio Code extension that formats selected SQL field lists into aligned columns **or** a single-column list, with smarter alias handling.

## Install the prebuilt `.vsix`

1. Open VS Code.
2. Run **Extensions: Install from VSIX...**
3. Pick the included `.vsix` file.

## New in v5

- Detects aliases **without** `AS` and changes them to use `AS` automatically when alias formatting is `normalize` or `align`
- Vertically aligns `AS` within a column **only when two or more items in that column are aliased**
- Adds a **list** layout mode that converts a multi-column field list into one field per line
- List mode also aligns aliased items vertically because the entire output becomes a single column

## New settings

```json
{
  "fieldListFormatter.layoutMode": "grid",
  "fieldListFormatter.aliasFormat": "align",
  "fieldListFormatter.aliasSpacingBeforeAs": 1,
  "fieldListFormatter.aliasSpacingAfterAs": 1
}
```

### `fieldListFormatter.layoutMode`

- `grid` → format into columns
- `list` → format one item per line

### `fieldListFormatter.aliasFormat`

- `preserve` → keep original alias wording and spacing exactly as selected
- `normalize` → if an alias is present, always emit `AS` with configured spacing
- `align` → same as normalize, but vertically align `AS` when a column has at least two aliased items

## New command

- **Field List Formatter: Format As List**

## Example: aliases without AS in grid mode

Input:

```sql
x.FIRST_REP_ID
x.FIRST_REP_NAME
x.SECOND_REP_ID AS Sec_Sales_Rep
x.SECOND_REP_NAME
x.SOLUTION_REP_NAME
x.BUSINESS_REP_ID
x.ACCOUNT_MGR_ID AS Account_Mgr
x.SPECIALIST_1
x.SPECIALIST_2
x.OWNER_ID AS Own_ID
x.LAST_OWNER_ID
x.CREATED_BY Created_By_Name
x.FINAL_CHECK_BY
x.LAST_HUMAN_MODIFIED_ID
x.ORIGINAL_LEAD_ID
x.RELATED_CONTACT_ID
x.CONSULTANT_ID
```

Example output:

```sql
  x.FIRST_REP_ID      , x.FIRST_REP_NAME                   , x.SECOND_REP_ID AS Sec_Sales_Rep, x.SECOND_REP_NAME       , x.SOLUTION_REP_NAME
, x.BUSINESS_REP_ID   , x.ACCOUNT_MGR_ID AS Account_Mgr    , x.SPECIALIST_1                  , x.SPECIALIST_2          , x.OWNER_ID AS Own_ID
, x.LAST_OWNER_ID     , x.CREATED_BY     AS Created_By_Name, x.FINAL_CHECK_BY                , x.LAST_HUMAN_MODIFIED_ID, x.ORIGINAL_LEAD_ID
, x.RELATED_CONTACT_ID, x.CONSULTANT_ID
```

## Example: list mode

Input:

```sql
  x.FIRST_REP_ID      , x.FIRST_REP_NAME                   , x.SECOND_REP_ID AS Sec_Sales_Rep, x.SECOND_REP_NAME       , x.SOLUTION_REP_NAME
, x.BUSINESS_REP_ID   , x.ACCOUNT_MGR_ID AS Account_Mgr    , x.SPECIALIST_1
```

Output:

```sql
  x.FIRST_REP_ID
, x.FIRST_REP_NAME
, x.SECOND_REP_ID  AS Sec_Sales_Rep
, x.SECOND_REP_NAME
, x.SOLUTION_REP_NAME
, x.BUSINESS_REP_ID
, x.ACCOUNT_MGR_ID AS Account_Mgr
, x.SPECIALIST_1
```

## New in v4

- Smarter handling of explicit aliases such as `AS [Alias Name]`
- Configurable alias formatting modes:
  - `preserve`
  - `normalize`
  - `align`
- Configurable spacing before and after `AS`
- Keeps the existing v3 improvements for:
  - SQL comment awareness
  - leading-comma first-row alignment
  - trailing-comma alignment
  - context menu and keyboard shortcuts
  - prebuilt `.vsix`

## Alias settings

```json
{
  "fieldListFormatter.aliasFormat": "normalize",
  "fieldListFormatter.aliasSpacingBeforeAs": 1,
  "fieldListFormatter.aliasSpacingAfterAs": 1
}
```

### `fieldListFormatter.aliasFormat`

- `preserve`
  - Leave alias spacing exactly as it appears in the selected text.
- `normalize`
  - Rewrite aliases using the configured `aliasSpacingBeforeAs` and `aliasSpacingAfterAs` values.
- `align`
  - Within each output column, vertically align the `AS` keyword based on the longest expression in that column, then apply the configured spacing values.

## Example input

```sql
x.FIRST_REP_ID
x.FIRST_REP_NAME
x.SECOND_REP_ID AS Sec_Sales_Rep
x.SECOND_REP_NAME
x.SOLUTION_REP_NAME
x.BUSINESS_REP_ID
x.ACCOUNT_MGR_ID AS Account_Mgr
x.SPECIALIST_1
x.SPECIALIST_2
x.OWNER_ID AS Own_ID
x.LAST_OWNER_ID
x.CREATED_BY Created_By_Name
x.FINAL_CHECK_BY
x.LAST_HUMAN_MODIFIED_ID
x.ORIGINAL_LEAD_ID
x.RELATED_CONTACT_ID
x.CONSULTANT_ID
```
## Example output (`aliasFormat = preserve`)

```sql
  x.FIRST_REP_ID      , x.FIRST_REP_NAME               , x.SECOND_REP_ID AS Sec_Sales_Rep, x.SECOND_REP_NAME       , x.SOLUTION_REP_NAME
, x.BUSINESS_REP_ID   , x.ACCOUNT_MGR_ID AS Account_Mgr, x.SPECIALIST_1                  , x.SPECIALIST_2          , x.OWNER_ID AS Own_ID
, x.LAST_OWNER_ID     , x.CREATED_BY Created_By_Name   , x.FINAL_CHECK_BY                , x.LAST_HUMAN_MODIFIED_ID, x.ORIGINAL_LEAD_ID
, x.RELATED_CONTACT_ID, x.CONSULTANT_ID
```

## Example output (`aliasFormat = normalize`)

```sql
  x.FIRST_REP_ID      , x.FIRST_REP_NAME               , x.SECOND_REP_ID AS Sec_Sales_Rep, x.SECOND_REP_NAME       , x.SOLUTION_REP_NAME
, x.BUSINESS_REP_ID   , x.ACCOUNT_MGR_ID AS Account_Mgr, x.SPECIALIST_1                  , x.SPECIALIST_2          , x.OWNER_ID AS Own_ID
, x.LAST_OWNER_ID     , x.CREATED_BY AS Created_By_Name, x.FINAL_CHECK_BY                , x.LAST_HUMAN_MODIFIED_ID, x.ORIGINAL_LEAD_ID
, x.RELATED_CONTACT_ID, x.CONSULTANT_ID
```

## Example output (`aliasFormat = align`)

```sql
  x.FIRST_REP_ID      , x.FIRST_REP_NAME                   , x.SECOND_REP_ID AS Sec_Sales_Rep, x.SECOND_REP_NAME       , x.SOLUTION_REP_NAME
, x.BUSINESS_REP_ID   , x.ACCOUNT_MGR_ID AS Account_Mgr    , x.SPECIALIST_1                  , x.SPECIALIST_2          , x.OWNER_ID AS Own_ID
, x.LAST_OWNER_ID     , x.CREATED_BY     AS Created_By_Name, x.FINAL_CHECK_BY                , x.LAST_HUMAN_MODIFIED_ID, x.ORIGINAL_LEAD_ID
, x.RELATED_CONTACT_ID, x.CONSULTANT_ID
```
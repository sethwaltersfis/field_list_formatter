const vscode = require('vscode');

function activate(context) {
    const subscriptions = [];

    subscriptions.push(vscode.commands.registerCommand(
        'fieldListFormatter.formatIntoFiveColumns',
        async () => formatSelection(5, 'grid')
    ));

    subscriptions.push(vscode.commands.registerCommand(
        'fieldListFormatter.formatIntoConfiguredColumns',
        async () => {
            const config = getConfig();
            await formatSelection(config.columns, config.layoutMode);
        }
    ));

    subscriptions.push(vscode.commands.registerCommand(
        'fieldListFormatter.promptForColumns',
        async () => {
            const config = getConfig();
            const answer = await vscode.window.showInputBox({
                prompt: 'Enter the number of columns to format into',
                value: String(config.columns),
                validateInput: value => {
                    const parsed = Number(value);
                    if (!Number.isInteger(parsed) || parsed < 1) {
                        return 'Enter a whole number greater than or equal to 1.';
                    }
                    return null;
                }
            });

            if (!answer) {
                return;
            }

            await formatSelection(Number(answer), 'grid');
        }
    ));

    subscriptions.push(vscode.commands.registerCommand(
        'fieldListFormatter.formatAsList',
        async () => formatSelection(1, 'list')
    ));

    for (let columns = 2; columns <= 9; columns++) {
        subscriptions.push(vscode.commands.registerCommand(
            `fieldListFormatter.formatInto${columns}Columns`,
            async () => formatSelection(columns, 'grid')
        ));
    }

    context.subscriptions.push(...subscriptions);
}

function getConfig() {
    const config = vscode.workspace.getConfiguration('fieldListFormatter');
    return {
        columns: Math.max(1, Number(config.get('columns', 5)) || 5),
        layoutMode: normalizeLayoutMode(config.get('layoutMode', 'grid')),
        commaStyle: normalizeCommaStyle(config.get('commaStyle', 'leading')),
        firstLinePrefixMode: normalizeFirstLinePrefixMode(config.get('firstLinePrefixMode', 'pad')),
        preserveIndentation: Boolean(config.get('preserveIndentation', false)),
        preserveBlankLines: Boolean(config.get('preserveBlankLines', false)),
        aliasFormat: normalizeAliasFormat(config.get('aliasFormat', 'align')),
        aliasSpacingBeforeAs: Math.max(0, Number(config.get('aliasSpacingBeforeAs', 1)) || 0),
        aliasSpacingAfterAs: Math.max(1, Number(config.get('aliasSpacingAfterAs', 1)) || 1)
    };
}

function normalizeLayoutMode(value) {
    return value === 'list' ? 'list' : 'grid';
}

function normalizeCommaStyle(value) {
    return value === 'trailing' ? 'trailing' : 'leading';
}

function normalizeFirstLinePrefixMode(value) {
    switch (value) {
        case 'none':
        case 'commaSpace':
        case 'pad':
            return value;
        default:
            return 'pad';
    }
}

function normalizeAliasFormat(value) {
    switch (value) {
        case 'preserve':
        case 'normalize':
        case 'align':
            return value;
        default:
            return 'align';
    }
}

async function formatSelection(columns, forcedLayoutMode) {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
        vscode.window.showInformationMessage('Field List Formatter: No active editor found.');
        return;
    }

    const document = editor.document;
    const config = getConfig();
    const normalizedColumns = forcedLayoutMode === 'list'
        ? 1
        : Math.max(1, Number(columns) || config.columns || 5);
    const layoutMode = forcedLayoutMode || config.layoutMode;

    await editor.edit(editBuilder => {
        for (const selection of editor.selections) {
            const range = selection.isEmpty
                ? new vscode.Range(selection.start.line, 0, selection.end.line, document.lineAt(selection.end.line).text.length)
                : selection;

            const originalText = document.getText(range);
            const formattedText = formatFieldList(originalText, {
                columns: normalizedColumns,
                layoutMode,
                commaStyle: config.commaStyle,
                firstLinePrefixMode: config.firstLinePrefixMode,
                preserveIndentation: config.preserveIndentation,
                preserveBlankLines: config.preserveBlankLines,
                aliasFormat: config.aliasFormat,
                aliasSpacingBeforeAs: config.aliasSpacingBeforeAs,
                aliasSpacingAfterAs: config.aliasSpacingAfterAs
            });

            editBuilder.replace(range, formattedText);
        }
    });
}

function formatFieldList(text, options) {
    const newline = text.includes('\r\n') ? '\r\n' : '\n';
    const parsed = parseSqlSelection(text, options);
    if (parsed.items.length === 0) {
        return text;
    }

    const normalizedColumns = options.layoutMode === 'list' ? 1 : Math.max(1, options.columns || 1);
    const rows = [];
    for (let i = 0; i < parsed.items.length; i += normalizedColumns) {
        rows.push(parsed.items.slice(i, i + normalizedColumns));
    }

    const aliasExpressionWidths = calculateAliasExpressionWidths(rows, normalizedColumns, options.aliasFormat, options.layoutMode);
    const renderedGrid = rows.map(row => row.map((item, colIndex) => renderItem(item, colIndex, aliasExpressionWidths, options)));
    const widths = Array.from({ length: normalizedColumns }, (_, colIndex) => {
        let maxLength = 0;
        for (const row of renderedGrid) {
            if (row[colIndex]) {
                maxLength = Math.max(maxLength, row[colIndex].length);
            }
        }
        return maxLength;
    });

    const rowStrings = renderedGrid.map((row, rowIndex) => renderRowFromGrid(row, rowIndex, renderedGrid.length, widths, parsed.baseIndent, options));
    return rowStrings.join(newline);
}

function renderRowFromGrid(row, rowIndex, rowCount, widths, baseIndent, options) {
    const pieces = [];
    for (let colIndex = 0; colIndex < row.length; colIndex++) {
        const itemText = row[colIndex];
        const isLastInRow = colIndex === row.length - 1;
        const isLastOverall = rowIndex === rowCount - 1 && isLastInRow;

        if (options.commaStyle === 'leading') {
            const prefix = getLeadingPrefix(rowIndex, colIndex, options.firstLinePrefixMode);
            let cell = prefix + itemText;
            if (!isLastInRow) {
                cell += ' '.repeat(Math.max(0, widths[colIndex] - itemText.length));
            }
            pieces.push(cell);
        } else {
            let cell = itemText;
            if (!isLastOverall) {
                cell += ' '.repeat(Math.max(0, widths[colIndex] - itemText.length));
                cell += ',';
                if (!isLastInRow) {
                    cell += ' ';
                }
            }
            pieces.push(cell);
        }
    }
    return baseIndent + pieces.join('');
}

function getLeadingPrefix(rowIndex, colIndex, firstLinePrefixMode) {
    const isFirstCell = rowIndex === 0 && colIndex === 0;
    if (!isFirstCell) {
        return ', ';
    }
    switch (firstLinePrefixMode) {
        case 'commaSpace':
            return ', ';
        case 'pad':
            return '  ';
        case 'none':
        default:
            return '';
    }
}

function parseSqlSelection(text, options) {
    const cleaned = stripSqlCommentsPreservingNewlines(text);
    const tokens = splitTopLevelFields(cleaned);
    const items = [];
    for (const token of tokens) {
        const normalized = normalizeFieldExpression(token);
        if (!normalized) {
            continue;
        }
        items.push(splitAliasParts(normalized));
    }

    const baseIndent = options.preserveIndentation ? getCommonIndentFromText(text) : '';
    return {
        items,
        baseIndent
    };
}

function stripSqlCommentsPreservingNewlines(text) {
    let result = '';
    let inSingleQuote = false;
    let inDoubleQuote = false;
    let inBracket = false;
    let inLineComment = false;
    let inBlockComment = false;

    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        const next = i + 1 < text.length ? text[i + 1] : '';

        if (inLineComment) {
            if (ch === '\n') {
                inLineComment = false;
                result += ch;
            }
            continue;
        }

        if (inBlockComment) {
            if (ch === '*' && next === '/') {
                inBlockComment = false;
                i++;
                continue;
            }
            if (ch === '\n') {
                result += ch;
            }
            continue;
        }

        if (inSingleQuote) {
            result += ch;
            if (ch === '\'' && next === '\'') {
                result += next;
                i++;
                continue;
            }
            if (ch === '\'') {
                inSingleQuote = false;
            }
            continue;
        }

        if (inDoubleQuote) {
            result += ch;
            if (ch === '"' && next === '"') {
                result += next;
                i++;
                continue;
            }
            if (ch === '"') {
                inDoubleQuote = false;
            }
            continue;
        }

        if (inBracket) {
            result += ch;
            if (ch === ']') {
                inBracket = false;
            }
            continue;
        }

        if (ch === '-' && next === '-') {
            inLineComment = true;
            i++;
            continue;
        }
        if (ch === '/' && next === '*') {
            inBlockComment = true;
            i++;
            continue;
        }
        if (ch === '\'') {
            inSingleQuote = true;
            result += ch;
            continue;
        }
        if (ch === '"') {
            inDoubleQuote = true;
            result += ch;
            continue;
        }
        if (ch === '[') {
            inBracket = true;
            result += ch;
            continue;
        }

        result += ch;
    }

    return result;
}

function splitTopLevelFields(text) {
    const tokens = [];
    let current = '';
    let inSingleQuote = false;
    let inDoubleQuote = false;
    let inBracket = false;
    let parenDepth = 0;

    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        const next = i + 1 < text.length ? text[i + 1] : '';

        if (inSingleQuote) {
            current += ch;
            if (ch === '\'' && next === '\'') {
                current += next;
                i++;
                continue;
            }
            if (ch === '\'') {
                inSingleQuote = false;
            }
            continue;
        }

        if (inDoubleQuote) {
            current += ch;
            if (ch === '"' && next === '"') {
                current += next;
                i++;
                continue;
            }
            if (ch === '"') {
                inDoubleQuote = false;
            }
            continue;
        }

        if (inBracket) {
            current += ch;
            if (ch === ']') {
                inBracket = false;
            }
            continue;
        }

        if (ch === '\'') {
            inSingleQuote = true;
            current += ch;
            continue;
        }
        if (ch === '"') {
            inDoubleQuote = true;
            current += ch;
            continue;
        }
        if (ch === '[') {
            inBracket = true;
            current += ch;
            continue;
        }
        if (ch === '(') {
            parenDepth++;
            current += ch;
            continue;
        }
        if (ch === ')' && parenDepth > 0) {
            parenDepth--;
            current += ch;
            continue;
        }

        if (parenDepth === 0 && (ch === ',' || ch === '\n' || ch === '\r')) {
            if (current.trim().length > 0) {
                tokens.push(current);
                current = '';
            }
            continue;
        }

        current += ch;
    }

    if (current.trim().length > 0) {
        tokens.push(current);
    }
    return tokens;
}

function getCommonIndentFromText(text) {
    const lines = text.replace(/\r\n/g, '\n').split('\n').filter(line => line.trim().length > 0);
    let smallest = null;
    for (const line of lines) {
        const indent = getVisualIndentBeforeField(line);
        if (smallest === null || indent.length < smallest.length) {
            smallest = indent;
        }
    }
    return smallest || '';
}

function getVisualIndentBeforeField(line) {
    const leadingWhitespace = (line.match(/^\s*/) || [''])[0];
    const afterWhitespace = line.slice(leadingWhitespace.length);
    if (afterWhitespace.startsWith(',')) {
        const remainder = afterWhitespace.slice(1);
        const spaceMatch = remainder.match(/^\s*/);
        const commaPadding = 1 + (spaceMatch ? spaceMatch[0].length : 0);
        return leadingWhitespace + ' '.repeat(commaPadding);
    }
    return leadingWhitespace;
}

function normalizeFieldExpression(token) {
    let trimmed = token.trim();
    if (!trimmed) {
        return '';
    }
    if (trimmed.startsWith(',')) {
        trimmed = trimmed.slice(1).trimStart();
    }
    if (trimmed.endsWith(',')) {
        trimmed = trimmed.slice(0, -1).trimEnd();
    }
    return trimmed;
}

function splitAliasParts(value) {
    const explicit = findExplicitAs(value);
    if (explicit) {
        return {
            hasAlias: true,
            aliasWasExplicit: true,
            raw: value,
            expression: explicit.expression,
            alias: explicit.alias
        };
    }

    const implicit = findImplicitAlias(value);
    if (implicit) {
        return {
            hasAlias: true,
            aliasWasExplicit: false,
            raw: value,
            expression: implicit.expression,
            alias: implicit.alias
        };
    }

    return {
        hasAlias: false,
        aliasWasExplicit: false,
        raw: value,
        expression: value,
        alias: ''
    };
}

function findExplicitAs(value) {
    let inSingleQuote = false;
    let inDoubleQuote = false;
    let inBracket = false;
    let parenDepth = 0;
    let candidate = -1;

    for (let i = 0; i < value.length - 1; i++) {
        const ch = value[i];
        const next = value[i + 1];
        const prev = i > 0 ? value[i - 1] : '';

        if (inSingleQuote) {
            if (ch === '\'' && next === '\'') {
                i++;
                continue;
            }
            if (ch === '\'') {
                inSingleQuote = false;
            }
            continue;
        }
        if (inDoubleQuote) {
            if (ch === '"' && next === '"') {
                i++;
                continue;
            }
            if (ch === '"') {
                inDoubleQuote = false;
            }
            continue;
        }
        if (inBracket) {
            if (ch === ']') {
                inBracket = false;
            }
            continue;
        }
        if (ch === '\'') {
            inSingleQuote = true;
            continue;
        }
        if (ch === '"') {
            inDoubleQuote = true;
            continue;
        }
        if (ch === '[') {
            inBracket = true;
            continue;
        }
        if (ch === '(') {
            parenDepth++;
            continue;
        }
        if (ch === ')' && parenDepth > 0) {
            parenDepth--;
            continue;
        }

        if (parenDepth === 0 && (ch === 'A' || ch === 'a') && (next === 'S' || next === 's')) {
            const beforeOk = i === 0 || /\s/.test(prev);
            const afterChar = i + 2 < value.length ? value[i + 2] : '';
            const afterOk = afterChar && /\s/.test(afterChar);
            if (beforeOk && afterOk) {
                candidate = i;
            }
        }
    }

    if (candidate < 0) {
        return null;
    }

    const expression = value.slice(0, candidate).replace(/\s+$/, '');
    const alias = value.slice(candidate + 2).replace(/^\s+/, '');
    if (!expression || !alias) {
        return null;
    }
    return { expression, alias };
}

function findImplicitAlias(value) {
    let boundary = -1;
    let inSingleQuote = false;
    let inDoubleQuote = false;
    let inBracket = false;
    let parenDepth = 0;

    for (let i = 0; i < value.length; i++) {
        const ch = value[i];
        const next = i + 1 < value.length ? value[i + 1] : '';

        if (inSingleQuote) {
            if (ch === '\'' && next === '\'') {
                i++;
                continue;
            }
            if (ch === '\'') {
                inSingleQuote = false;
            }
            continue;
        }
        if (inDoubleQuote) {
            if (ch === '"' && next === '"') {
                i++;
                continue;
            }
            if (ch === '"') {
                inDoubleQuote = false;
            }
            continue;
        }
        if (inBracket) {
            if (ch === ']') {
                inBracket = false;
            }
            continue;
        }
        if (ch === '\'') {
            inSingleQuote = true;
            continue;
        }
        if (ch === '"') {
            inDoubleQuote = true;
            continue;
        }
        if (ch === '[') {
            inBracket = true;
            continue;
        }
        if (ch === '(') {
            parenDepth++;
            continue;
        }
        if (ch === ')' && parenDepth > 0) {
            parenDepth--;
            continue;
        }

        if (parenDepth === 0 && /\s/.test(ch)) {
            boundary = i;
        }
    }

    if (boundary < 0) {
        return null;
    }

    const expression = value.slice(0, boundary).trimEnd();
    const alias = value.slice(boundary).trim();
    if (!expression || !alias) {
        return null;
    }
    if (!isAliasCandidate(alias)) {
        return null;
    }
    return { expression, alias };
}

function isAliasCandidate(alias) {
    return /^\[[^\]]+\]$/.test(alias)
        || /^"[^"]+"$/.test(alias)
        || /^`[^`]+`$/.test(alias)
        || /^[A-Za-z_#@][\w$#@]*$/.test(alias);
}

function calculateAliasExpressionWidths(rows, columnCount, aliasFormat, layoutMode) {
    const widths = Array.from({ length: columnCount }, () => ({ max: 0, count: 0 }));
    rows.forEach(row => {
        row.forEach((item, colIndex) => {
            const effectiveIndex = layoutMode === 'list' ? 0 : colIndex;
            if (item && item.hasAlias) {
                widths[effectiveIndex].max = Math.max(widths[effectiveIndex].max, item.expression.length);
                widths[effectiveIndex].count += 1;
            }
        });
    });
    return widths.map(info => {
        if (aliasFormat !== 'align') {
            return 0;
        }
        return info.count >= 2 ? info.max : 0;
    });
}

function renderItem(item, colIndex, aliasExpressionWidths, options) {
    if (!item.hasAlias || options.aliasFormat === 'preserve') {
        return item.raw;
    }

    const effectiveIndex = options.layoutMode === 'list' ? 0 : colIndex;
    let expression = item.expression;
    const targetWidth = aliasExpressionWidths[effectiveIndex] || 0;
    if (options.aliasFormat === 'align' && targetWidth > 0) {
        expression = expression.padEnd(targetWidth, ' ');
    }

    const beforeAsSpaces = ' '.repeat(options.aliasSpacingBeforeAs);
    const afterAsSpaces = ' '.repeat(options.aliasSpacingAfterAs);
    return `${expression}${beforeAsSpaces}AS${afterAsSpaces}${item.alias}`;
}

function deactivate() {}

module.exports = {
    activate,
    deactivate,
    formatFieldList,
    parseSqlSelection,
    splitTopLevelFields,
    splitAliasParts,
    findExplicitAs,
    findImplicitAlias,
    renderItem,
    calculateAliasExpressionWidths
};
